const Film = require('../models/film.model');
const filmRepository = {
    countAllFilms: async () => {
        return Film.countDocuments();
    },
    getTop10RatedFilms: async () => {
        return Film.find().sort({ avgRate: -1 }).limit(10);
    },
    findFilmsByPublishedYear: async (year) => {
        return Film.find({ publishedYear: year });
    },
    findFilmsByCountry: async (country) => {
        return Film.find({ country: country });
    },
    findFilmsByActor: async (actorName) => {
        return Film.find({ actors: actorName });
    
    },
    findFilmsByNameKeyword: async (keyword) => {
        const regex = new RegExp(keyword, 'i');
        return Film.find({ name: regex });
    },
    findFilmsByEpisodeCountRange: async (minEpisodes, maxEpisodes) => {
        return Film.find({
            $expr: {
                $and: [
                    { $gte: [{ $size: "$episodes" }, minEpisodes] },
                    { $lte: [{ $size: "$episodes" }, maxEpisodes] }
                ]
            }
        });
    }
};
module.exports = filmRepository;