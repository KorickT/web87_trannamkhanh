const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const mongoose = require('mongoose');
const filmRepository = require('./repositories/film.repository');

const app = express();
const PORT = 5000; 

app.use(cors()); 
app.use(bodyParser.json()); 

mongoose.connect('mongodb://127.0.0.1:27017/web87', {
})
.then(() => console.log('Connected to MongoDB'))
.catch(err => console.error('MongoDB connection error:', err));

app.get('/films/top-10', async (req, res) => {
    try {
        let top10Films = await filmRepository.getTop10RatedFilms();
        res.json(top10Films);
    } catch (error) {
        console.error('Error fetching top 10 films:', error);
        res.status(500).json({ message: 'Error fetching films' });
    }
});
app.get('/films/count', async (req, res) => {
    try {
        let filmCount = await filmRepository.countAllFilms();
        res.json({ count: filmCount });
    } catch (error) {
        console.error('Error counting films:', error);
        res.status(500).json({ message: 'Error counting films' });
    }
});
app.get('/films/year/:year', async (req, res) => {
    try {
        let year = parseInt(req.params.year);
        let filmsByYear = await filmRepository.findFilmsByPublishedYear(year);
        res.json(filmsByYear);
    } catch (error) {
        console.error('Error fetching films by year:', error);
        res.status(500).json({ message: 'Error fetching films' });
    }
});
app.get('/films/country/:country', async (req, res) => {
    try {
        let country = req.params.country;
        let filmsByCountry = await filmRepository.findFilmsByCountry(country);
        res.json(filmsByCountry);
    } catch (error) {
        console.error('Error fetching films by ciuntry:', error);
        res.status(500).json({ message: 'Error fetching films' });
    }
});
app.get('/films/actor/:actorName', async (req, res) => {
    try {
        let actorName = req.params.actorName;
        let filmsByActor = await filmRepository.findFilmsByActor(actorName);
        res.json(filmsByActor);
    } catch (error) {
        console.error('Error fetching gilms by actor:', error);
        res.status(500).json({ message: 'Error fetching film' });
    }
});
app.get('/films/name-keyword/:keyword', async (req, res) => {
    try {
        let keyword = req.params.keyword;
        let filmsByNameKeyword = await filmRepository.findFilmsByNameKeyword(keyword);
        
        res.json(filmsByNameKeyword);
    } catch (error) {
        console.error('Error fetching films by name keyword:', error);
        res.status(500).json({ message: 'Error fetching film' });
    }
});


