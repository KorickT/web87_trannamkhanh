const mongoose = require('mongoose');
const FilmSchema = new mongoose.Schema({
    name: String, 
    country: String, 
    director: String, 
    actors: [String], 
    description: String, 
    genres: String, 
    publishedYear: Number, 
    avgRate: Number, 
    images: [String], 
    episodes: [{
        number: Number,
        url: String
    }]
});
module.exports = mongoose.model('Film', FilmSchema);